<?php
include_once __DIR__ . '/../config/session.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login/');
    exit();
}
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once "../config/database.php";
include "../config/app.php";
include "objective.php";
include_once __DIR__ . '/../helpers/activity_logger.php';

$database = new Database();
$db = $database->getConnection();

if (!$db) {
    $_SESSION['error'] = 'Database connection failed.';
    header("Location: " . $base_url . "/objectives/");
    exit();
}

$objective = new Objective($db);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['error'] = 'Invalid CSRF token.';
        header("Location: " . $base_url . "/objectives/");
        exit();
    }

    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'create':
            $objective->objectives_details = $_POST['objectives_details'];
            $objective->focus_area = $_POST['focus_area'];

            if ($objective->create()) {
                $log_message = "Created new objective '{$objective->objectives_details}' (ID: {$objective->objectives_id})";
                log_activity($db, (int)$_SESSION['user_id'], 'Created Objective', 'Objectives', $log_message);
                $_SESSION['success'] = 'Objective was created successfully.';
            } else {
                $_SESSION['error'] = 'Unable to create objective.';
            }
            header("Location: " . $base_url . "/objectives/");
            exit();

        case 'update':
            $objective->objectives_id = $_POST['objectives_id'];

            $objective_before = new Objective($db);
            $objective_before->objectives_id = $objective->objectives_id;
            $objective_before->readOne();

            $objective->objectives_details = $_POST['objectives_details'];
            $objective->focus_area = $_POST['focus_area'];

            if ($objective->update()) {
                $details = [];
                if ($objective_before->objectives_details !== $objective->objectives_details) {
                    $details[] = "details from '{$objective_before->objectives_details}' to '{$objective->objectives_details}'";
                }
                if ($objective_before->focus_area !== $objective->focus_area) {
                    $details[] = "focus area from '{$objective_before->focus_area}' to '{$objective->focus_area}'";
                }

                if (!empty($details)) {
                    $log_message = "Updated objective '{$objective_before->objectives_details}': " . implode(', ', $details) . ".";
                } else {
                    $log_message = "Attempted to update objective '{$objective_before->objectives_details}', but no values were changed.";
                }
                
                log_activity($db, (int)$_SESSION['user_id'], 'Updated Objective', 'Objectives', $log_message);
                $_SESSION['success'] = 'Objective was updated successfully.';
            } else {
                $_SESSION['error'] = 'Unable to update objective.';
            }
            header("Location: " . $base_url . "/objectives/");
            exit();

        case 'delete':
            $objective->objectives_id = $_POST['objectives_id'];

            $objective->readOne();
            $deleted_objective_name = $objective->objectives_details;

            if ($objective->delete()) {
                $log_message = "Deleted objective '{$deleted_objective_name}' (ID: {$objective->objectives_id})";
                log_activity($db, (int)$_SESSION['user_id'], 'Deleted Objective', 'Objectives', $log_message);
                $_SESSION['success'] = 'Objective was deleted successfully.';
            } else {
                $_SESSION['error'] = 'Unable to delete objective.';
            }
            header("Location: " . $base_url . "/objectives/");
            exit();

        default:
            $_SESSION['error'] = 'Invalid action.';
            header("Location: " . $base_url . "/objectives/");
            exit();
    }
} else {
    $_SESSION['error'] = 'Invalid request method.';
    header("Location: " . $base_url . "/objectives/");
    exit();
}
?>