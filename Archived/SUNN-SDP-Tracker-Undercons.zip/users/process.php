<?php
include_once __DIR__ . '/../config/session.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login/');
    exit();
}
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once "../config/database.php";
include "../config/app.php";
include "user.php";
include_once __DIR__ . '/../helpers/activity_logger.php';



$database = new Database();
$db = $database->getConnection();

if (!$db) {
    $_SESSION['error'] = 'Database connection failed.';
    header("Location: " . $base_url . "/users/");
    exit();
}

$user = new User($db);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['error'] = 'Invalid CSRF token.';
        header("Location: " . $base_url . "/users/");
        exit();
    }

    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'create':
            $user->full_name = $_POST['full_name'];
            $user->username = $_POST['username'];
            $user->position = $_POST['position'];
            $user->r_matrix_id = empty($_POST['r_matrix_id']) ? null : $_POST['r_matrix_id'];
            $user->password = $_POST['password'];
            $user->role = $_POST['role'];

            if ($user->create()) {
                $log_message = "Created new user '{$user->full_name}' (ID: {$user->user_id})";
                log_activity($db, (int)$_SESSION['user_id'], 'Created User', 'Users', $log_message);
                $_SESSION['success'] = 'User was created successfully.';
            } else {
                $_SESSION['error'] = 'Unable to create user. Username may already be in use.';
            }
            header("Location: " . $base_url . "/users/");
            exit();

        case 'update':
            $user->user_id = $_POST['user_id'];

            // Get user state before update
            $user_before = new User($db);
            $user_before->user_id = $user->user_id;
            $user_before->readOne();

            $user->full_name = $_POST['full_name'];
            $user->username = $_POST['username'];
            $user->position = $_POST['position'];
            $user->r_matrix_id = empty($_POST['r_matrix_id']) ? null : $_POST['r_matrix_id'];
            $user->role = $_POST['role'];
            $user->password = $_POST['password'] ?? ''; // Password might be empty if not changed

            if ($user->update()) {
                $details = [];
                if ($user_before->full_name !== $user->full_name) {
                    $details[] = "full name from '{$user_before->full_name}' to '{$user->full_name}'";
                }
                if ($user_before->username !== $user->username) {
                    $details[] = "username from '{$user_before->username}' to '{$user->username}'";
                }
                if ($user_before->position !== $user->position) {
                    $details[] = "position from '{$user_before->position}' to '{$user->position}'";
                }
                if ($user_before->r_matrix_id != $user->r_matrix_id) {
                    $new_office_name = $user->getOfficeUnitById($user->r_matrix_id);
                    $details[] = "office from '{$user_before->office}' to '{$new_office_name}'";
                }

                // Role comparison
                $role_map = [1 => 'Admin', 2 => 'Staff', 'Admin' => 'Admin', 'Faculty' => 'Faculty', 'Staff' => 'Staff', 'Dean' => 'Dean', 'Director' => 'Director'];
                $new_role_name = $role_map[$_POST['role']] ?? 'Staff';
                if ($user_before->role !== $new_role_name) {
                    $details[] = "role from '{$user_before->role}' to '{$new_role_name}'";
                }

                if (!empty($user->password)) {
                    $details[] = "password updated";
                }

                if (!empty($details)) {
                    $log_message = "Updated user '{$user_before->full_name}': " . implode(', ', $details) . ".";
                } else {
                    $log_message = "Attempted to update user '{$user_before->full_name}', but no values were changed.";
                }
                
                log_activity($db, (int)$_SESSION['user_id'], 'Updated User', 'Users', $log_message);
                $_SESSION['success'] = 'User was updated successfully.';
            } else {
                $_SESSION['error'] = 'Unable to update user.';
            }
            header("Location: " . $base_url . "/users/");
            exit();

        case 'delete':
            $user->user_id = $_POST['user_id'];

            // Get user details before deleting
            $user->readOne();
            $deleted_user_name = $user->full_name;

            if ($user->delete()) {
                $log_message = "Deleted user '{$deleted_user_name}' (ID: {$user->user_id})";
                log_activity($db, (int)$_SESSION['user_id'], 'Deleted User', 'Users', $log_message);
                $_SESSION['success'] = 'User was deleted successfully.';
            } else {
                $_SESSION['error'] = 'Unable to delete user.';
            }
            header("Location: " . $base_url . "/users/");
            exit();

        default:
            $_SESSION['error'] = 'Invalid action.';
            header("Location: " . $base_url . "/users/");
            exit();
    }
} else {
    $_SESSION['error'] = 'Invalid request method.';
    header("Location: " . $base_url . "/users/");
    exit();
}
?>