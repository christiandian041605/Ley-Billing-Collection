<?php
include_once __DIR__ . '/../config/session.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login/");
    exit();
}

// Restrict to Admin only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: ../dashboard/");
    exit();
}

include "../config/app.php";
include_once "../config/database.php";

$database = new Database();
$db = $database->getConnection();

// Fetch database info if needed
$db_name = getenv('DB_NAME') ?: 'db_ley_supply_inventory';

?>
<!doctype html>
<html lang="en">

<!--begin::Head-->
<?php include "../header.php"; ?>
<!--end::Head-->

<!--begin::Body-->

<body class="layout-fixed bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">

        <!--begin::Header-->
        <?php include "../navbar.php"; ?>
        <!--end::Header-->


        <!--begin::Sidebar-->
        <?php include "../sidebar.php"; ?>
        <!--end::Sidebar-->

        <!--begin::App Main-->
        <main class="app-main">
            <!--begin::App Content Header-->
            <div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0">Database Backup</h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/dashboard/">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    Database Backup
                                </li>
                            </ol>
                        </div>
                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Container-->
            </div>
            <!--end::App Content-->
            <!--begin::App Content-->
            <div class="app-content">

                <!--begin::Container-->
                <div class="container-fluid">

                    <div class="row justify-content-center">
                        <div class="col-lg-6">
                            <div class="card card-outline card-success">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="bi bi-database-fill-down me-2"></i>Export Database
                                    </h3>
                                </div>
                                <div class="card-body">
                                    <div class="text-center mb-4">
                                        <div class="display-1 text-success mb-3">
                                            <i class="bi bi-database-check"></i>
                                        </div>
                                        <h4>Ready to Back Up</h4>
                                        <p class="text-muted">
                                            Click the button below to generate a full SQL export of your database.
                                            This includes all table structures and data.
                                        </p>
                                    </div>

                                    <div class="alert alert-info">
                                        <ul class="mb-0">
                                            <li><strong>Database:</strong>
                                                <?php echo htmlspecialchars($db_name); ?>
                                            </li>
                                            <li><strong>Format:</strong> SQL (compatible with phpMyAdmin)</li>
                                            <li><strong>Include:</strong> Structure & Data</li>
                                        </ul>
                                    </div>

                                    <div class="d-grid gap-2 mt-4">
                                        <a href="backup_db.php?action=download" class="btn btn-success btn-lg">
                                            <i class="bi bi-download me-2"></i>Download Backup Now
                                        </a>
                                    </div>
                                </div>
                                <div class="card-footer text-center">
                                    <small class="text-muted">
                                        <i class="bi bi-shield-lock me-1"></i> For security, database backups are only
                                        accessible to Administrators.
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!--end::Container-->

            </div>
            <!--end::App Content-->
        </main>
        <!--end::App Main-->



        <!--begin::Footer-->
        <?php include "../footer.php"; ?>
        <!--end::Footer-->

    </div>
    <!--end::App Wrapper-->

    <!--begin::Script-->
    <?php include "../script.php"; ?>
    <!--end::Script-->

</body>
<!--end::Body-->

</html>