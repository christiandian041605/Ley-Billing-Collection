<?php
require_once 'config/database.php';

$sql = [
    "ALTER TABLE tbl_deliveries ADD payment_status ENUM('Unpaid', 'Partially Paid', 'Paid') NOT NULL DEFAULT 'Unpaid' AFTER total_amount;",
    "DROP TABLE IF EXISTS tbl_charge_invoice_items;",
    "CREATE TABLE tbl_or_delivery (
        id INT AUTO_INCREMENT PRIMARY KEY,
        or_id INT,
        delivery_id INT,
        applied_amount DECIMAL(15, 2),
        FOREIGN KEY (or_id) REFERENCES tbl_official_receipts(id) ON DELETE CASCADE,
        FOREIGN KEY (delivery_id) REFERENCES tbl_deliveries(id) ON DELETE CASCADE
    );"
];

try {
    $db = new Database();
    $conn = $db->getConnection();
    $conn->beginTransaction();

    foreach ($sql as $query) {
        $conn->exec($query);
        echo "SUCCESS: " . $query . "\n";
    }

    $conn->commit();
    echo "Database migration completed successfully.\n";

} catch (PDOException $e) {
    if (isset($conn) && $conn->inTransaction()) {
        $conn->rollBack();
    }
    die("Database migration failed: " . $e->getMessage() . "\n");
}

