-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 15, 2026 at 03:28 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ley_billing`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_activity_logs`
--

CREATE TABLE `tbl_activity_logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(255) NOT NULL,
  `module` varchar(255) NOT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_activity_logs`
--

INSERT INTO `tbl_activity_logs` (`log_id`, `user_id`, `action`, `module`, `details`, `created_at`) VALUES
(13, 1, 'Updated App Setting', 'App Settings', 'Attempted to update app settings, but no values were changed.', '2025-12-07 12:17:46'),
(14, 1, 'Created User', 'Users', 'Created new user &#039;admin2 2 2&#039; (ID: 2)', '2025-12-07 12:29:55'),
(15, 1, 'Created User', 'Users', 'Created new user &#039;1 1 1&#039; (ID: 3)', '2025-12-07 12:34:24'),
(16, 1, 'Updated User', 'Users', 'Attempted to update user &#039;1 1 1&#039;, but no values were changed.', '2025-12-07 12:46:46'),
(17, 1, 'Updated User', 'Users', 'Updated user &#039;1 1 1&#039;: full name from &#039;1 1 1&#039; to &#039;encoder 1 1&#039;, username from &#039;111&#039; to &#039;encoder&#039;, password updated.', '2025-12-07 12:47:26'),
(18, 1, 'Created Customer', 'Customers', 'Created new customer &#039;1&#039; (ID: 1, Type: Private)', '2025-12-07 14:00:38'),
(19, 1, 'Updated Customer', 'Customers', 'Updated customer &#039;1&#039;: Address changed from &#039;1&#039; to &#039;11&#039;', '2025-12-07 14:00:49'),
(20, 1, 'Deleted Customer', 'Customers', 'Deleted customer &#039;1&#039; (ID: 1)', '2025-12-07 14:00:51'),
(21, 1, 'Created Customer', 'Customers', 'Created new customer &#039;123&#039; (ID: 2, Type: Private)', '2025-12-07 14:03:39'),
(22, 1, 'Updated Customer', 'Customers', 'Updated customer &#039;123&#039;: Customer Type changed from &#039;Private&#039; to &#039;Business&#039;', '2025-12-07 14:03:43'),
(23, 1, 'Created User', 'Users', 'Created new user &#039;1 1&#039; (ID: 4)', '2025-12-07 14:17:53'),
(24, 1, 'Deleted User', 'Users', 'Deleted user &#039;1 1&#039; (ID: 4)', '2025-12-07 14:18:01'),
(25, 1, 'Created Customer', 'Customers', 'Created new customer &#039;123123&#039; (ID: 3, Type: Business)', '2025-12-07 14:18:13'),
(26, 1, 'Deleted Customer', 'Customers', 'Deleted customer &#039;123123&#039; (ID: 3)', '2025-12-07 14:18:16'),
(27, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 1', '2025-12-07 14:21:25'),
(28, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 2)', '2025-12-07 14:26:26'),
(29, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 2)', '2025-12-07 14:26:50'),
(30, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 2)', '2025-12-07 14:28:55'),
(31, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 2)', '2025-12-07 14:29:00'),
(32, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 2)', '2025-12-07 14:29:08'),
(33, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 2)', '2025-12-07 14:29:22'),
(34, 1, 'Created Customer', 'Customers', 'Created new customer &#039;g&#039; (ID: 4, Type: Government)', '2025-12-07 14:29:42'),
(35, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0002&#039; (ID: 3)', '2025-12-07 14:30:02'),
(36, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 2)', '2025-12-07 14:30:42'),
(37, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0003&#039; (ID: 4)', '2025-12-07 14:33:30'),
(38, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 4', '2025-12-07 14:33:35'),
(39, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 3', '2025-12-07 14:36:12'),
(40, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0002&#039; (ID: 5)', '2025-12-07 14:36:34'),
(41, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0002&#039; (ID: 5)', '2025-12-07 14:36:41'),
(42, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0002&#039; (ID: 5)', '2025-12-07 14:36:47'),
(43, 1, 'CREATE', 'Payments', 'Created payment OR# 123 for customer ID 4', '2025-12-07 14:37:46'),
(44, 1, 'UPDATE', 'Payments', 'Updated payment OR# 123', '2025-12-07 14:37:52'),
(45, 1, 'DELETE', 'Payments', 'Deleted payment OR# 123', '2025-12-07 14:38:04'),
(46, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 5', '2025-12-07 14:38:10'),
(47, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 2', '2025-12-07 14:40:51'),
(48, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 6)', '2025-12-07 14:41:39'),
(49, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 6)', '2025-12-07 14:41:48'),
(50, 1, 'CREATE', 'Payments', 'Created payment OR# 123 for customer ID 2', '2025-12-07 14:42:17'),
(51, 1, 'UPDATE', 'Payments', 'Updated payment OR# 123', '2025-12-07 14:42:43'),
(52, 1, 'DELETE', 'Payments', 'Deleted payment OR# 123', '2025-12-07 14:42:45'),
(53, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 6)', '2025-12-07 14:43:26'),
(54, 1, 'CREATE', 'Payments', 'Created payment OR# 123 for customer ID 2', '2025-12-07 14:44:07'),
(55, 1, 'UPDATE', 'Payments', 'Updated payment OR# 123', '2025-12-07 14:44:15'),
(56, 1, 'UPDATE', 'Payments', 'Updated payment OR# 123', '2025-12-07 14:44:25'),
(57, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0001', '2025-12-07 14:54:24'),
(58, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0002', '2025-12-07 14:59:21'),
(59, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0002', '2025-12-07 14:59:58'),
(60, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0002', '2025-12-07 15:04:00'),
(61, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0002', '2025-12-07 15:05:39'),
(62, 1, 'Created Official Receipt', 'Official Receipts', 'Created official receipt &#039;OR-2025-1884&#039; (ID: 18)', '2025-12-07 15:19:21'),
(63, 1, 'Updated Official Receipt', 'Official Receipts', 'Updated official receipt &#039;OR-2025-1884&#039; (ID: 18)', '2025-12-07 15:24:37'),
(64, 1, 'Deleted Official Receipt', 'Official Receipts', 'Deleted official receipt &#039;OR-2025-1884&#039; (ID: 18)', '2025-12-07 15:24:39'),
(65, 1, 'Updated Official Receipt', 'Official Receipts', 'Updated official receipt &#039;12344&#039; (ID: 3)', '2025-12-07 15:24:45'),
(66, 1, 'Updated Official Receipt', 'Official Receipts', 'Updated official receipt &#039;12344&#039; (ID: 3)', '2025-12-07 15:24:50'),
(67, 1, 'Updated Official Receipt', 'Official Receipts', 'Updated official receipt &#039;12344&#039; (ID: 3)', '2025-12-07 15:25:14'),
(68, 1, 'Deleted Official Receipt', 'Official Receipts', 'Deleted official receipt &#039;12344&#039; (ID: 3)', '2025-12-07 15:25:19'),
(69, 1, 'Created Official Receipt', 'Official Receipts', 'Created official receipt &#039;OR-2025-0601&#039; (ID: 19)', '2025-12-07 15:25:39'),
(70, 1, 'Deleted Official Receipt', 'Official Receipts', 'Deleted official receipt &#039;OR-2025-0601&#039; (ID: 19)', '2025-12-07 15:25:41'),
(71, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 6', '2025-12-07 15:25:47'),
(72, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 7)', '2025-12-07 15:26:19'),
(73, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 7)', '2025-12-07 15:26:22'),
(74, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 7', '2025-12-07 15:26:24'),
(75, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 8)', '2025-12-07 15:27:48'),
(76, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 8', '2025-12-07 15:27:50'),
(77, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 9)', '2025-12-07 15:29:53'),
(78, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 9', '2025-12-07 15:30:01'),
(79, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 10)', '2025-12-07 15:30:15'),
(80, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 10)', '2025-12-07 15:30:17'),
(81, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 10', '2025-12-07 15:30:19'),
(82, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 11)', '2025-12-07 15:30:30'),
(83, 1, 'CREATE', 'Payments', 'Created payment OR# 123 for customer ID 2', '2025-12-07 15:30:46'),
(84, 1, 'DELETE', 'Payments', 'Deleted payment OR# 123', '2025-12-07 15:34:02'),
(85, 1, 'CREATE', 'Payments', 'Created payment OR# 123 for customer ID 2', '2025-12-07 15:34:10'),
(86, 1, 'Created Official Receipt', 'Official Receipts', 'Created official receipt &#039;OR-2025-3688&#039; (ID: 22)', '2025-12-07 15:34:37'),
(87, 1, 'CREATE', 'Payments', 'Created payment OR# 12344 for customer ID 2', '2025-12-08 13:26:41'),
(88, 1, 'UPDATE', 'Payments', 'Updated payment OR# 12344', '2025-12-08 13:26:45'),
(89, 1, 'Updated Bank', 'Banks', 'Updated bank ID: 1', '2025-12-08 13:59:04'),
(90, 1, 'Deleted Bank', 'Banks', 'Deleted bank ID: 1', '2025-12-08 13:59:06'),
(91, 1, 'Updated User', 'Users', 'Attempted to update user &#039;admin2 2 2&#039;, but no values were changed.', '2025-12-08 13:59:18'),
(92, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 11)', '2025-12-08 13:59:31'),
(93, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;123&#039; (ID: 12)', '2025-12-08 14:10:39'),
(94, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0002', '2025-12-08 14:36:03'),
(95, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0002', '2025-12-08 14:37:53'),
(96, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0001', '2025-12-08 14:37:55'),
(97, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0001', '2025-12-08 14:38:13'),
(98, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 12', '2025-12-08 14:38:19'),
(99, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 11', '2025-12-08 14:38:21'),
(100, 1, 'Created Customer', 'Customers', 'Created new customer &#039;12&#039; (ID: 5, Type: Business)', '2025-12-09 12:05:51'),
(101, 1, 'Updated Customer', 'Customers', 'Updated customer &#039;1212&#039;: Name changed from &#039;12&#039; to &#039;1212&#039;, Business Name changed from &#039;12&#039; to &#039;1212&#039;, Address changed from &#039;12&#039; to &#039;1212&#039;, Contact Number changed from &#039;12&#039; to &#039;1212&#039;, Email changed from &#039;1@gmail.com&#039; to &#039;112@gmail.com&#039;', '2025-12-09 12:06:03'),
(102, 1, 'Deleted Customer', 'Customers', 'Deleted customer &#039;1212&#039; (ID: 5)', '2025-12-09 12:06:06'),
(103, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 13)', '2025-12-09 12:06:22'),
(104, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 13', '2025-12-09 12:06:27'),
(105, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0002', '2025-12-09 12:43:11'),
(106, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0001', '2025-12-09 12:43:19'),
(107, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0002', '2025-12-09 12:43:23'),
(108, 1, 'DELETE', 'Payments', 'Deleted payment OR# 123', '2025-12-09 12:43:34'),
(109, 1, 'DELETE', 'Payments', 'Deleted payment OR# 12344', '2025-12-09 12:43:36'),
(110, 1, 'DELETE', 'Payments', 'Deleted payment OR# OR-2025-3688', '2025-12-09 12:43:37'),
(111, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0001', '2025-12-09 12:44:27'),
(112, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0002', '2025-12-09 12:44:38'),
(113, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0003', '2025-12-09 12:44:49'),
(114, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0002', '2025-12-09 12:44:56'),
(115, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0003', '2025-12-09 12:44:58'),
(116, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0001', '2025-12-09 12:45:02'),
(117, 1, 'Deleted Customer', 'Customers', 'Deleted customer &#039;123&#039; (ID: 2)', '2025-12-09 12:53:59'),
(118, 1, 'Deleted Customer', 'Customers', 'Deleted customer &#039;g&#039; (ID: 4)', '2025-12-09 12:54:01'),
(119, 1, 'Deleted User', 'Users', 'Deleted user &#039;admin2 2 2&#039; (ID: 2)', '2025-12-09 12:54:15'),
(120, 1, 'Updated User', 'Users', 'Updated user &#039;encoder 1 1&#039;: full name from &#039;encoder 1 1&#039; to &#039;encoder 1&#039;, position from &#039;1&#039; to &#039;encoder&#039;.', '2025-12-09 12:54:37'),
(121, 1, 'Created Customer', 'Customers', 'Created new customer &#039;Private customer&#039; (ID: 6, Type: Private)', '2025-12-09 12:56:46'),
(122, 1, 'Updated Customer', 'Customers', 'Updated customer &#039;Private customer&#039;: Customer Type changed from &#039;Private&#039; to &#039;Business&#039;', '2025-12-09 12:56:54'),
(123, 1, 'Updated Customer', 'Customers', 'Updated customer &#039;Private customer&#039;: Customer Type changed from &#039;Business&#039; to &#039;Private&#039;', '2025-12-09 12:56:59'),
(124, 1, 'Created Customer', 'Customers', 'Created new customer &#039;1&#039; (ID: 7, Type: Business)', '2025-12-09 12:57:08'),
(125, 1, 'Deleted Customer', 'Customers', 'Deleted customer &#039;1&#039; (ID: 7)', '2025-12-09 12:57:11'),
(126, 1, 'Created Customer', 'Customers', 'Created new customer &#039;Business Cust&#039; (ID: 8, Type: Business)', '2025-12-09 12:57:41'),
(127, 1, 'Created Customer', 'Customers', 'Created new customer &#039;Gov Cust&#039; (ID: 9, Type: Government)', '2025-12-09 12:58:27'),
(128, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0001', '2025-12-09 13:03:24'),
(129, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0001', '2025-12-09 13:03:27'),
(130, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 14)', '2025-12-09 13:04:15'),
(131, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;LEY-202512-0001&#039; (ID: 14)', '2025-12-09 13:04:46'),
(132, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 15)', '2025-12-09 13:05:06'),
(133, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 15)', '2025-12-09 13:05:15'),
(134, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 15)', '2025-12-09 13:05:23'),
(135, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 15', '2025-12-09 13:05:30'),
(136, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 14', '2025-12-09 13:09:37'),
(137, 1, 'Updated Customer', 'Customers', 'Updated customer &#039;Gov Cust&#039;: Address changed from &#039;test&#039; to &#039;LGU Toboso&#039;', '2025-12-09 13:10:05'),
(138, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 16)', '2025-12-09 13:10:29'),
(139, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0001', '2025-12-09 13:25:16'),
(140, 1, 'CREATE', 'Payments', 'Created payment OR# OR-2025-1884 for customer ID 9', '2025-12-09 13:32:49'),
(141, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-2025-1884', '2025-12-09 13:33:00'),
(142, 1, 'CREATE', 'Payments', 'Created payment OR# 123 for customer ID 9', '2025-12-09 13:43:41'),
(143, 1, 'DELETE', 'Payments', 'Deleted payment OR# 123', '2025-12-09 13:44:20'),
(144, 1, 'DELETE', 'Payments', 'Deleted payment OR# OR-2025-1884', '2025-12-09 13:44:23'),
(145, 1, 'CREATE', 'Payments', 'Created payment OR# 123 for customer ID 9', '2025-12-09 13:53:14'),
(146, 1, 'DELETE', 'Payments', 'Deleted payment OR# 123', '2025-12-09 13:54:36'),
(147, 1, 'CREATE', 'Payments', 'Created payment OR# 213 for customer ID 9', '2025-12-09 13:54:53'),
(148, 1, 'UPDATE', 'Payments', 'Updated payment OR# 213', '2025-12-09 13:55:06'),
(149, 1, 'UPDATE', 'Payments', 'Updated payment OR# 213', '2025-12-09 13:56:28'),
(150, 1, 'DELETE', 'Payments', 'Deleted payment OR# 213', '2025-12-09 13:56:38'),
(151, 1, 'CREATE', 'Payments', 'Created payment OR# 123 for customer ID 9', '2025-12-09 13:56:48'),
(152, 1, 'UPDATE', 'Payments', 'Updated payment OR# 123', '2025-12-09 13:58:11'),
(153, 1, 'UPDATE', 'Payments', 'Updated payment OR# 123', '2025-12-09 14:05:34'),
(154, 1, 'UPDATE', 'Payments', 'Updated payment OR# 123', '2025-12-09 14:07:52'),
(155, 1, 'UPDATE', 'Payments', 'Updated payment OR# 123', '2025-12-09 14:08:12'),
(156, 1, 'UPDATE', 'Payments', 'Updated payment OR# 123', '2025-12-09 14:16:52'),
(157, 1, 'CREATE', 'Payments', 'Created payment OR# 123123 for customer ID 9', '2025-12-09 14:27:26'),
(158, 1, 'DELETE', 'Payments', 'Deleted payment OR# 123', '2025-12-10 03:21:20'),
(159, 1, 'DELETE', 'Payments', 'Deleted payment OR# 123123', '2025-12-10 03:21:21'),
(160, 1, 'Updated Customer', 'Customers', 'Updated customer &#039;Private cust&#039;: Name changed from &#039;Private customer&#039; to &#039;Private cust&#039;', '2025-12-10 06:09:37'),
(161, 1, 'DELETE', 'Payments', 'Deleted payment OR# OR-20251210-000001', '2025-12-10 06:24:23'),
(162, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 16', '2025-12-10 06:24:28'),
(163, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0001', '2025-12-10 06:24:31'),
(164, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 17)', '2025-12-10 06:34:45'),
(165, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 17)', '2025-12-10 06:38:00'),
(166, 1, 'CREATE', 'Payments', 'Created payment OR# OR1 for customer ID 9', '2025-12-10 06:40:09'),
(167, 1, 'CREATE', 'Payments', 'Created payment OR# OR2 for customer ID 9', '2025-12-10 06:40:40'),
(168, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR2', '2025-12-10 06:41:58'),
(169, 1, 'DELETE', 'Payments', 'Deleted payment OR# OR2', '2025-12-10 06:42:17'),
(170, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR1', '2025-12-10 06:42:49'),
(171, 1, 'DELETE', 'Payments', 'Deleted payment OR# OR1', '2025-12-10 06:43:02'),
(172, 1, 'CREATE', 'Payments', 'Created payment OR# or1 for customer ID 9', '2025-12-10 06:43:35'),
(173, 1, 'DELETE', 'Payments', 'Deleted payment OR# or1', '2025-12-10 06:43:48'),
(174, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 17)', '2025-12-10 06:49:47'),
(175, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 17', '2025-12-10 06:49:49'),
(176, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 18)', '2025-12-10 07:01:14'),
(177, 1, 'CREATE', 'Payments', 'Created payment OR# OR 123 for customer ID 9', '2025-12-10 07:01:34'),
(178, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR 123', '2025-12-10 07:01:45'),
(179, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR 123', '2025-12-10 07:01:54'),
(180, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 18)', '2025-12-10 07:02:18'),
(181, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 18', '2025-12-10 07:02:20'),
(182, 1, 'Created Bank', 'Banks', 'Added new bank: Land Bank - Toboso', '2025-12-10 07:14:32'),
(183, 1, 'Updated Bank', 'Banks', 'Updated bank ID: 2', '2025-12-10 07:19:53'),
(184, 1, 'Updated Bank', 'Banks', 'Updated bank ID: 2', '2025-12-10 07:19:59'),
(185, 1, 'Updated Bank', 'Banks', 'Updated bank ID: 2', '2025-12-10 07:20:06'),
(186, 1, 'Created Bank', 'Banks', 'Added new bank: 1 - 1', '2025-12-10 07:20:10'),
(187, 1, 'Deleted Bank', 'Banks', 'Deleted bank ID: 3', '2025-12-10 07:20:12'),
(188, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0001', '2025-12-10 07:26:21'),
(189, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0002', '2025-12-10 07:26:54'),
(190, 1, 'UPDATE', 'Deliveries', 'Updated delivery: DR-2025-0002', '2025-12-10 07:41:29'),
(191, 1, 'UPDATE', 'Deliveries', 'Updated delivery: DR-2025-0002', '2025-12-10 07:42:58'),
(192, 1, 'UPDATE', 'Deliveries', 'Updated delivery: DR-2025-0001', '2025-12-10 07:55:38'),
(193, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0001', '2025-12-10 07:55:41'),
(194, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0002', '2025-12-10 07:55:44'),
(195, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 19)', '2025-12-10 07:57:08'),
(196, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0002&#039; (ID: 20)', '2025-12-10 08:02:12'),
(197, 1, 'CREATE', 'Payments', 'Created payment OR# 1 for customer ID 8', '2025-12-10 08:02:35'),
(198, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 20', '2025-12-10 08:02:39'),
(199, 1, 'DELETE', 'Payments', 'Deleted payment OR# 1', '2025-12-10 08:02:43'),
(200, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0002&#039; (ID: 21)', '2025-12-10 08:04:14'),
(201, 1, 'CREATE', 'Payments', 'Created payment OR# 123 for customer ID 8', '2025-12-10 08:04:50'),
(202, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 19)', '2025-12-10 08:05:07'),
(203, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR 123', '2025-12-10 08:05:54'),
(204, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR 123', '2025-12-10 08:06:29'),
(205, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR 123', '2025-12-10 08:07:00'),
(206, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR 123', '2025-12-10 08:07:40'),
(207, 1, 'DELETE', 'Payments', 'Deleted payment OR# OR 123', '2025-12-10 08:08:04'),
(208, 1, 'CREATE', 'Payments', 'Created payment OR# 123123 for customer ID 9', '2025-12-10 08:08:40'),
(209, 1, 'UPDATE', 'Payments', 'Updated payment OR# 123', '2025-12-10 08:16:58'),
(210, 1, 'DELETE', 'Payments', 'Deleted payment OR# 123123', '2025-12-10 08:17:11'),
(211, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 19', '2025-12-10 08:17:14'),
(212, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 21', '2025-12-10 08:17:17'),
(213, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 22)', '2025-12-10 08:24:05'),
(214, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0001', '2025-12-10 08:24:16'),
(215, 1, 'CREATE', 'Payments', 'Created payment OR# 1231 for customer ID 9', '2025-12-10 08:25:27'),
(216, 1, 'DELETE', 'Payments', 'Deleted payment OR# 123', '2025-12-10 12:49:50'),
(217, 1, 'DELETE', 'Payments', 'Deleted payment OR# 1231', '2025-12-10 12:49:56'),
(218, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 22', '2025-12-10 13:01:18'),
(219, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0001', '2025-12-10 13:03:17'),
(220, 1, 'Created Customer', 'Customers', 'Created new customer &#039;1&#039; (ID: 10, Type: Private)', '2025-12-10 13:19:23'),
(221, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0001', '2025-12-10 13:20:43'),
(222, 1, 'UPDATE', 'Deliveries', 'Updated delivery: DR-2025-0001', '2025-12-10 13:21:16'),
(223, 1, 'Updated Customer', 'Customers', 'Updated customer &#039;11&#039;: Customer Type changed from &#039;Private&#039; to &#039;Business&#039;, Name changed from &#039;1&#039; to &#039;11&#039;, Business Name changed from &#039;1&#039; to &#039;11&#039;, Address changed from &#039;1&#039; to &#039;11&#039;, Contact Number changed from &#039;1&#039; to &#039;11&#039;, Email changed from &#039;1@gmail.com&#039; to &#039;11@gmail.com&#039;', '2025-12-10 13:24:19'),
(224, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0001', '2025-12-10 13:24:31'),
(225, 1, 'Deleted Customer', 'Customers', 'Deleted customer &#039;11&#039; (ID: 10)', '2025-12-10 13:24:35'),
(226, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0001', '2025-12-10 13:24:52'),
(227, 1, 'UPDATE', 'Deliveries', 'Updated delivery: DR-2025-00012', '2025-12-10 13:27:58'),
(228, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-00012', '2025-12-10 13:32:57'),
(229, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0001', '2025-12-10 13:33:07'),
(230, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0002', '2025-12-10 13:33:19'),
(231, 1, 'UPDATE', 'Deliveries', 'Updated delivery: DR-2025-00023', '2025-12-10 13:33:30'),
(232, 1, 'UPDATE', 'Deliveries', 'Updated delivery: DR-2025-00023', '2025-12-10 13:37:57'),
(233, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0024', '2025-12-10 13:38:06'),
(234, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0025', '2025-12-10 13:38:15'),
(235, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0025', '2025-12-10 13:38:18'),
(236, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0024', '2025-12-10 13:38:20'),
(237, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0001&#039; (ID: 23)', '2025-12-10 13:39:17'),
(238, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 23)', '2025-12-10 13:39:25'),
(239, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0002&#039; (ID: 24)', '2025-12-10 13:39:42'),
(240, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 24', '2025-12-10 13:39:45'),
(241, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0002&#039; (ID: 25)', '2025-12-10 13:40:09'),
(242, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0003&#039; (ID: 26)', '2025-12-10 13:40:20'),
(243, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0003&#039; (ID: 26)', '2025-12-10 13:40:29'),
(244, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 26', '2025-12-10 13:40:37'),
(245, 1, 'CREATE', 'Payments', 'Created payment OR# 001 for customer ID 8', '2025-12-10 13:41:44'),
(246, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0003&#039; (ID: 27)', '2025-12-10 13:42:04'),
(247, 1, 'CREATE', 'Payments', 'Created payment OR# 002 for customer ID 6', '2025-12-10 13:42:58'),
(248, 1, 'DELETE', 'Payments', 'Deleted payment OR# 002', '2025-12-10 13:49:21'),
(249, 1, 'CREATE', 'Payments', 'Created payment OR# 002 for customer ID 6', '2025-12-10 13:50:49'),
(250, 1, 'UPDATE', 'Payments', 'Updated payment OR# 002', '2025-12-10 13:51:05'),
(251, 1, 'UPDATE', 'Payments', 'Updated payment OR# 002', '2025-12-10 13:51:09'),
(252, 1, 'UPDATE', 'Payments', 'Updated payment OR# 002', '2025-12-10 13:51:27'),
(253, 1, 'DELETE', 'Payments', 'Deleted payment OR# 002', '2025-12-10 13:51:36'),
(254, 1, 'CREATE', 'Payments', 'Created payment OR# 002 for customer ID 6', '2025-12-10 13:52:09'),
(255, 1, 'UPDATE', 'Payments', 'Updated payment OR# 002', '2025-12-10 13:52:35'),
(256, 1, 'DELETE', 'Payments', 'Deleted payment OR# 002', '2025-12-10 13:52:56'),
(257, 1, 'CREATE', 'Payments', 'Created payment OR# 002 for customer ID 6', '2025-12-10 13:53:15'),
(258, 1, 'DELETE', 'Payments', 'Deleted payment OR# 002', '2025-12-10 13:59:59'),
(259, 1, 'CREATE', 'Payments', 'Created payment OR# 002 for customer ID 6', '2025-12-10 14:00:19'),
(260, 1, 'UPDATE', 'Payments', 'Updated payment OR# 002', '2025-12-10 14:03:30'),
(261, 1, 'UPDATE', 'Payments', 'Updated payment OR# 002', '2025-12-10 14:03:43'),
(262, 1, 'UPDATE', 'Payments', 'Updated payment OR# 002', '2025-12-10 14:11:19'),
(263, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0002&#039; (ID: 25)', '2025-12-10 14:11:55'),
(264, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0001&#039; (ID: 23)', '2025-12-10 14:20:45'),
(265, 1, 'DELETE', 'Payments', 'Deleted payment OR# 001', '2025-12-10 14:21:09'),
(266, 1, 'CREATE', 'Payments', 'Created payment OR# OR-202512-0001 for customer ID 8', '2025-12-10 14:21:35'),
(267, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0001', '2025-12-10 14:21:46'),
(268, 1, 'CREATE', 'Payments', 'Created payment OR# OR-202512-0002 for customer ID 9', '2025-12-10 14:22:06'),
(269, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0002', '2025-12-10 14:22:54'),
(270, 1, 'Created Bank', 'Banks', 'Added new bank: BDO - Toboso', '2025-12-10 14:23:15'),
(271, 1, 'Updated Bank', 'Banks', 'Updated bank ID: 2', '2025-12-10 14:23:18'),
(272, 1, 'Updated User', 'Users', 'Updated user &#039;Admin System&#039;: username from &#039;admin&#039; to &#039;super&#039;, password updated.', '2025-12-13 01:11:47'),
(273, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0001', '2025-12-13 02:15:32'),
(274, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0024', '2025-12-13 02:15:42'),
(275, 1, 'CREATE', 'Payments', 'Created payment OR# OR-202512-0003 for customer ID 8', '2025-12-13 02:16:06'),
(276, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0004&#039; (ID: 28)', '2025-12-13 02:19:59'),
(277, 1, 'DELETE', 'Payments', 'Deleted payment OR# OR-202512-0002', '2025-12-13 02:20:12'),
(278, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-00023', '2025-12-13 02:20:30'),
(279, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2025-0024', '2025-12-13 02:20:34'),
(280, 1, 'DELETE', 'Payments', 'Deleted payment OR# 002', '2025-12-13 02:20:38'),
(281, 1, 'DELETE', 'Payments', 'Deleted payment OR# OR-202512-0001', '2025-12-13 02:20:40'),
(282, 1, 'DELETE', 'Payments', 'Deleted payment OR# OR-202512-0003', '2025-12-13 02:20:42'),
(283, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0001', '2025-12-13 02:26:32'),
(284, 1, 'CREATE', 'Payments', 'Created payment OR# OR-202512-0001-test for customer ID 8', '2025-12-13 02:31:29'),
(285, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0001-test', '2025-12-13 02:33:05'),
(286, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0001-test', '2025-12-13 02:33:42'),
(287, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0001-test', '2025-12-13 02:35:53'),
(288, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0001-test', '2025-12-13 02:36:06'),
(289, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0001-test', '2025-12-13 02:42:34'),
(290, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0001-test', '2025-12-13 02:42:42'),
(291, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0001-test', '2025-12-13 02:42:55'),
(292, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0001-test', '2025-12-13 02:46:12'),
(293, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0002-test', '2025-12-13 02:46:45'),
(294, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 25', '2025-12-13 02:46:58'),
(295, 1, 'Deleted Charge Invoice', 'Charge Invoices', 'Deleted charge invoice with ID: 28', '2025-12-13 02:47:00'),
(296, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0004&#039; (ID: 29)', '2025-12-13 02:49:46'),
(297, 1, 'CREATE', 'Payments', 'Created payment OR# OR-202512-0001 for customer ID 9', '2025-12-13 02:50:20'),
(298, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0001', '2025-12-13 02:53:12'),
(299, 1, 'DELETE', 'Payments', 'Deleted payment OR# OR-202512-0001', '2025-12-13 02:53:31'),
(300, 1, 'CREATE', 'Payments', 'Created payment OR# OR-202512-0001 for customer ID 9', '2025-12-13 03:06:25'),
(301, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0001-forCheck', '2025-12-13 03:07:33'),
(302, 1, 'CREATE', 'Payments', 'Created payment OR# OR-202512-0002 for customer ID 6', '2025-12-13 03:08:11'),
(303, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0002', '2025-12-13 03:10:42'),
(304, 1, 'Created Customer', 'Customers', 'Created new customer &#039;Dela Cruz (Private)&#039; (ID: 11, Type: Private)', '2025-12-13 03:14:12'),
(305, 1, 'Updated Customer', 'Customers', 'Updated customer &#039;Dela Cruz (Private)&#039;: Business Name changed from &#039;Inasal&#039; to &#039;Materials&#039;', '2025-12-13 03:14:35'),
(306, 1, 'Created Customer', 'Customers', 'Created new customer &#039;1&#039; (ID: 12, Type: Private)', '2025-12-13 03:14:44'),
(307, 1, 'Deleted Customer', 'Customers', 'Deleted customer &#039;1&#039; (ID: 12)', '2025-12-13 03:14:46'),
(308, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-00012', '2025-12-13 03:20:12'),
(309, 1, 'CREATE', 'Payments', 'Created payment OR# OR-202512-0003 for customer ID 6', '2025-12-13 03:21:00'),
(310, 1, 'CREATE', 'Payments', 'Created payment OR# OR-202512-0004 for customer ID 9', '2025-12-13 03:21:37'),
(311, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0004', '2025-12-13 03:22:02'),
(312, 1, 'Created Customer', 'Customers', 'Created new customer &#039;1&#039; (ID: 13, Type: Private)', '2025-12-13 04:39:09'),
(313, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-00131', '2025-12-13 04:39:21'),
(314, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0132', '2025-12-13 04:39:35'),
(315, 1, 'CREATE', 'Payments', 'Created payment OR# OR-202512-0005 for customer ID 13', '2025-12-13 04:40:10'),
(316, 1, 'Updated Customer', 'Customers', 'Updated customer &#039;test&#039;: Name changed from &#039;1&#039; to &#039;test&#039;', '2025-12-13 05:10:02'),
(317, 1, 'CREATE', 'Payments', 'Created payment OR# OR-202512-0006 for customer ID 13', '2025-12-13 05:10:27'),
(318, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0003', '2025-12-13 05:13:41'),
(319, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0001-test', '2025-12-13 05:15:50'),
(320, 1, 'CREATE', 'Payments', 'Created payment OR# OR-202512-0007 for customer ID 13', '2025-12-13 05:17:51'),
(321, 1, 'Created Customer', 'Customers', 'Created new customer &#039;TestGov&#039; (ID: 14, Type: Business)', '2025-12-13 05:18:29'),
(322, 1, 'Updated Customer', 'Customers', 'Updated customer &#039;TestGov&#039;: Customer Type changed from &#039;Business&#039; to &#039;Government&#039;', '2025-12-13 05:18:38'),
(323, 1, 'Created Customer', 'Customers', 'Created new customer &#039;1&#039; (ID: 15, Type: Government)', '2025-12-13 05:18:49'),
(324, 1, 'Deleted Customer', 'Customers', 'Deleted customer &#039;1&#039; (ID: 15)', '2025-12-13 05:18:52'),
(325, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0134', '2025-12-13 05:19:13'),
(326, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0135', '2025-12-13 05:19:21'),
(327, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0005&#039; (ID: 30)', '2025-12-13 05:19:35'),
(328, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0005&#039; (ID: 30)', '2025-12-13 05:20:32'),
(329, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0006&#039; (ID: 31)', '2025-12-13 05:20:43'),
(330, 1, 'CREATE', 'Payments', 'Created payment OR# OR-202512-0008 for customer ID 14', '2025-12-13 05:21:27'),
(331, 1, 'UPDATE', 'Payments', 'Updated payment OR# OR-202512-0008', '2025-12-13 05:21:46'),
(332, 1, 'CREATE', 'Payments', 'Created payment OR# OR-202512-0009 for customer ID 14', '2025-12-13 05:23:03'),
(333, 1, 'CREATE', 'Payments', 'Created payment OR# PVT-20251213-153512-275 for customer ID 13', '2025-12-13 07:35:44'),
(334, 1, 'CREATE', 'Payments', 'Created payment OR# OR-202512-0010 for customer ID 14', '2025-12-13 07:36:04'),
(335, 1, 'UPDATE', 'Payments', 'Updated payment OR# PVT-20251213-153512-275', '2025-12-13 07:36:19'),
(336, 1, 'Updated Customer', 'Customers', 'Updated customer &#039;testBbusiness&#039;: Customer Type changed from &#039;Private&#039; to &#039;Business&#039;, Name changed from &#039;test&#039; to &#039;testBbusiness&#039;', '2025-12-13 07:39:00'),
(337, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2025-0136', '2025-12-17 02:37:55'),
(338, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202512-0007&#039; (ID: 32)', '2025-12-17 02:38:13'),
(339, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0007&#039; (ID: 32)', '2025-12-17 02:42:35'),
(340, 1, 'Updated Charge Invoice', 'Charge Invoices', 'Updated charge invoice &#039;CI-202512-0007&#039; (ID: 32)', '2025-12-17 02:44:05'),
(341, 1, 'DELETE', 'Payments', 'Deleted payment OR# OR-202512-0010', '2025-12-17 02:46:04'),
(342, 1, 'DELETE', 'Payments', 'Deleted payment OR# OR-202512-0008', '2025-12-17 02:46:51'),
(343, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2026-0001', '2026-01-15 05:59:06'),
(344, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2026-0002', '2026-01-15 05:59:39'),
(345, 1, 'UPDATE', 'Deliveries', 'Updated delivery: DR-2026-0002', '2026-01-15 05:59:53'),
(346, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2026-0001', '2026-01-15 14:15:28'),
(347, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2026-0003', '2026-01-15 14:21:52'),
(348, 1, 'CREATE', 'Deliveries', 'Created delivery: DR-2026-0004', '2026-01-15 14:22:32'),
(349, 1, 'DELETE', 'Deliveries', 'Deleted delivery: DR-2026-0004', '2026-01-15 14:22:36'),
(350, 1, 'UPDATE', 'Deliveries', 'Updated delivery: DR-2026-0003', '2026-01-15 14:23:53'),
(351, 1, 'Created Charge Invoice', 'Charge Invoices', 'Created charge invoice &#039;CI-202601-0001&#039; (ID: 33)', '2026-01-15 14:24:21'),
(352, 1, 'CREATE', 'Payments', 'Created payment OR# PVT-20260115-222638-866 for customer ID 8', '2026-01-15 14:27:01'),
(353, 1, 'UPDATE', 'Payments', 'Updated payment OR# PVT-20260115-222638-866', '2026-01-15 14:27:46');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_app_setting`
--

CREATE TABLE `tbl_app_setting` (
  `setting_id` int(11) NOT NULL,
  `app_name` varchar(100) NOT NULL,
  `address` text DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `about` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `logo` varchar(255) NOT NULL DEFAULT 'default.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_app_setting`
--

INSERT INTO `tbl_app_setting` (`setting_id`, `app_name`, `address`, `contact_number`, `email`, `about`, `updated_at`, `logo`) VALUES
(1, 'Ley Billing and Collection', 'Municipality of Toboso', '1', 'tobosoley@gmail.com', 'Ley Toboso', '2025-12-07 10:03:21', 'default.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_banks`
--

CREATE TABLE `tbl_banks` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `branch` varchar(255) DEFAULT NULL,
  `bank_code` varchar(50) DEFAULT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_banks`
--

INSERT INTO `tbl_banks` (`id`, `bank_name`, `branch`, `bank_code`, `status`, `created_at`, `updated_at`) VALUES
(2, 'Land Bank', 'Toboso', 'LBP1', 'Active', '2025-12-10 07:14:32', '2025-12-10 07:20:06'),
(4, 'BDO', 'Toboso', 'BDO001', 'Active', '2025-12-10 14:23:15', '2025-12-10 14:23:15');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_charge_invoices`
--

CREATE TABLE `tbl_charge_invoices` (
  `id` int(11) NOT NULL,
  `invoice_no` varchar(50) NOT NULL,
  `invoice_date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `address` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `payment_status` enum('Unpaid','Partially Paid','Paid') DEFAULT 'Unpaid',
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `withholding_tax_5` decimal(15,2) DEFAULT 0.00 COMMENT 'Government withholding tax 5%',
  `withholding_tax_1` decimal(15,2) DEFAULT 0.00 COMMENT 'Government withholding tax 1%',
  `net_amount` decimal(15,2) DEFAULT 0.00 COMMENT 'Amount after withholding tax deductions',
  `is_government` tinyint(1) DEFAULT 0 COMMENT 'Flag for government transactions'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_charge_invoices`
--

INSERT INTO `tbl_charge_invoices` (`id`, `invoice_no`, `invoice_date`, `customer_id`, `address`, `total_amount`, `payment_status`, `created_by`, `created_at`, `updated_at`, `withholding_tax_5`, `withholding_tax_1`, `net_amount`, `is_government`) VALUES
(23, 'CI-202512-0001', '2025-12-10', 8, 'Escalante', 150.00, 'Partially Paid', 1, '2025-12-10 21:39:17', '2025-12-10 22:21:46', 0.00, 0.00, 150.00, 0),
(27, 'CI-202512-0003', '2025-12-10', 6, 'Toboso', 400.00, 'Paid', 1, '2025-12-10 21:42:04', '2025-12-10 22:11:19', 0.00, 0.00, 400.00, 0),
(29, 'CI-202512-0004', '2025-12-13', 9, 'LGU Toboso', 500.00, 'Paid', 1, '2025-12-13 10:49:46', '2025-12-13 11:22:02', 25.00, 5.00, 470.00, 1),
(30, 'CI-202512-0005', '2025-12-13', 14, 'test', 2000.00, 'Partially Paid', 1, '2025-12-13 13:19:35', '2025-12-17 10:46:51', 100.00, 20.00, 1880.00, 1),
(31, 'CI-202512-0006', '2025-12-13', 14, 'test', 5000.00, 'Unpaid', 1, '2025-12-13 13:20:43', '2025-12-17 10:46:51', 250.00, 50.00, 4700.00, 1),
(32, 'CI-202512-0007', '2025-12-17', 14, 'test', 1000.00, 'Unpaid', 1, '2025-12-17 10:38:13', NULL, 50.00, 10.00, 940.00, 1),
(33, 'CI-202601-0001', '2026-01-15', 9, 'LGU Toboso', 123.00, 'Unpaid', 1, '2026-01-15 22:24:21', NULL, 6.15, 1.23, 115.62, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customers`
--

CREATE TABLE `tbl_customers` (
  `id` int(11) NOT NULL,
  `customer_type` enum('Private','Business','Government') NOT NULL DEFAULT 'Private',
  `name` varchar(255) NOT NULL,
  `business_name` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `contact_number` varchar(50) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_customers`
--

INSERT INTO `tbl_customers` (`id`, `customer_type`, `name`, `business_name`, `address`, `contact_number`, `email`, `created_at`) VALUES
(6, 'Private', 'Private cust', 'Hollowblocks', 'Toboso', '090909', 'sample@gmail.com', '2025-12-09 20:56:46'),
(8, 'Business', 'Business Cust', 'Construction', 'Escalante', '0909', 'sample@gmail.com', '2025-12-09 20:57:41'),
(9, 'Government', 'Gov Cust', 'LGU', 'LGU Toboso', '0909', 'sample@gmail.com', '2025-12-09 20:58:27'),
(11, 'Private', 'Dela Cruz (Private)', 'Materials', 'Toboso', '0909', 'sample@gmail.com', '2025-12-13 11:14:12'),
(13, 'Business', 'testBbusiness', '1', '1', '1', '1@gmail.com', '2025-12-13 12:39:09'),
(14, 'Government', 'TestGov', 'TestGov', 'test', '09', 'lay@gmail.com', '2025-12-13 13:18:29');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_deliveries`
--

CREATE TABLE `tbl_deliveries` (
  `id` int(11) NOT NULL,
  `delivery_no` varchar(50) NOT NULL,
  `delivery_date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `delivery_type` enum('DR V','DR Government') DEFAULT 'DR V' COMMENT 'Delivery receipt category',
  `address` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `payment_status` enum('Unpaid','Partially Paid','Paid') DEFAULT 'Unpaid',
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `checker` varchar(255) DEFAULT NULL,
  `driver` varchar(255) DEFAULT NULL,
  `plate_number` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_deliveries`
--

INSERT INTO `tbl_deliveries` (`id`, `delivery_no`, `delivery_date`, `customer_id`, `delivery_type`, `address`, `total_amount`, `payment_status`, `created_by`, `created_at`, `checker`, `driver`, `plate_number`) VALUES
(22, 'DR-2025-0001', '2025-12-13', 8, 'DR V', 'Escalante', 500.00, 'Paid', 1, '2025-12-13 10:26:32', NULL, NULL, NULL),
(23, 'DR-2025-0002-test', '2025-12-13', 9, 'DR Government', 'LGU Toboso', 500.00, 'Unpaid', 1, '2025-12-13 10:46:45', NULL, NULL, NULL),
(24, 'DR-2025-0001-forCheck', '2025-12-13', 6, 'DR V', 'Toboso', 500.00, 'Paid', 1, '2025-12-13 11:07:33', NULL, NULL, NULL),
(25, 'DR-2025-00012', '2025-12-13', 6, 'DR V', 'Toboso', 700.00, 'Paid', 1, '2025-12-13 11:20:12', NULL, NULL, NULL),
(26, 'DR-2025-00131', '2025-12-13', 13, 'DR V', '1', 1000.00, 'Paid', 1, '2025-12-13 12:39:21', NULL, NULL, NULL),
(27, 'DR-2025-0132', '2025-12-13', 13, 'DR V', '1', 500.00, 'Paid', 1, '2025-12-13 12:39:35', NULL, NULL, NULL),
(28, 'DR-2025-0133', '2025-12-13', 13, 'DR V', '1', 100.00, 'Paid', 1, '2025-12-13 12:59:01', NULL, NULL, NULL),
(29, 'DR-2025-0134', '2025-12-13', 14, 'DR Government', 'test', 2000.00, 'Unpaid', 1, '2025-12-13 13:19:13', NULL, NULL, NULL),
(30, 'DR-2025-0135', '2025-12-13', 14, 'DR Government', 'test', 5000.00, 'Unpaid', 1, '2025-12-13 13:19:21', NULL, NULL, NULL),
(31, 'DR-2025-0136', '2025-12-17', 14, 'DR Government', 'test', 1000.00, 'Unpaid', 1, '2025-12-17 10:37:55', NULL, NULL, NULL),
(33, 'DR-2026-0002', '2026-01-15', 8, 'DR V', 'Escalante', 123.00, 'Partially Paid', 1, '2026-01-15 13:59:39', '11', '11', '11'),
(34, 'DR-2026-0003', '2026-01-15', 9, 'DR Government', 'LGU Toboso', 123.00, 'Unpaid', 1, '2026-01-15 22:21:52', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_invoice_deliveries`
--

CREATE TABLE `tbl_invoice_deliveries` (
  `id` int(11) NOT NULL,
  `charge_invoice_id` int(11) NOT NULL,
  `delivery_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_invoice_deliveries`
--

INSERT INTO `tbl_invoice_deliveries` (`id`, `charge_invoice_id`, `delivery_id`) VALUES
(9, 29, 23),
(12, 30, 29),
(13, 31, 30),
(16, 32, 31),
(17, 33, 34);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_official_receipts`
--

CREATE TABLE `tbl_official_receipts` (
  `id` int(11) NOT NULL,
  `or_no` varchar(50) NOT NULL,
  `or_date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `amount_received` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payment_type` enum('Cash','Check','Bank Transfer','GCash') DEFAULT 'Cash',
  `bank_id` int(11) DEFAULT NULL,
  `cheque_no` varchar(100) DEFAULT NULL,
  `cheque_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `cheque_name` varchar(255) DEFAULT NULL COMMENT 'Check name for government transactions',
  `check_amount` decimal(15,2) DEFAULT NULL COMMENT 'Check amount verification',
  `payment_details` text DEFAULT NULL COMMENT 'Additional payment details'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_official_receipts`
--

INSERT INTO `tbl_official_receipts` (`id`, `or_no`, `or_date`, `customer_id`, `amount_received`, `payment_type`, `bank_id`, `cheque_no`, `cheque_date`, `notes`, `created_by`, `created_at`, `cheque_name`, `check_amount`, `payment_details`) VALUES
(48, 'OR-202512-0001-test', '2025-12-13', 8, 1000.00, 'Cash', NULL, NULL, NULL, 'test', 1, '2025-12-13 10:31:29', NULL, NULL, NULL),
(50, 'OR-202512-0001', '2025-12-13', 9, 400.00, 'Cash', NULL, NULL, NULL, 'test', 1, '2025-12-13 11:06:25', NULL, NULL, NULL),
(51, 'OR-202512-0002', '2025-12-13', 6, 400.00, 'Check', 2, '123', '2025-12-13', '123', 1, '2025-12-13 11:08:11', NULL, 123.00, NULL),
(52, 'OR-202512-0003', '2025-12-13', 6, 800.00, 'Cash', NULL, NULL, NULL, 'test', 1, '2025-12-13 11:21:00', NULL, NULL, NULL),
(53, 'OR-202512-0004', '2025-12-13', 9, 70.00, 'Cash', NULL, NULL, NULL, 'test', 1, '2025-12-13 11:21:37', NULL, NULL, NULL),
(54, 'OR-202512-0005', '2025-12-13', 13, 1000.00, 'Cash', NULL, NULL, NULL, '1', 1, '2025-12-13 12:40:10', NULL, NULL, NULL),
(55, 'OR-202512-0006', '2025-12-13', 13, 500.00, 'Cash', NULL, NULL, NULL, 'test', 1, '2025-12-13 13:10:27', NULL, NULL, NULL),
(56, 'OR-202512-0007', '2025-12-13', 13, 100.00, 'Cash', NULL, NULL, NULL, 'test', 1, '2025-12-13 13:17:51', NULL, NULL, NULL),
(58, 'OR-202512-0009', '2025-12-13', 14, 1280.00, 'Cash', NULL, NULL, NULL, 'test', 1, '2025-12-13 13:23:03', NULL, NULL, NULL),
(59, 'PVT-20251213-153512-275', '2025-12-13', 13, 100.00, 'Cash', NULL, NULL, NULL, 'test', 1, '2025-12-13 15:35:44', NULL, NULL, NULL),
(61, 'PVT-20260115-222638-866', '2026-01-15', 8, 1000.00, 'Cash', NULL, NULL, NULL, '123', 1, '2026-01-15 22:27:01', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_or_delivery`
--

CREATE TABLE `tbl_or_delivery` (
  `id` int(11) NOT NULL,
  `or_id` int(11) NOT NULL,
  `delivery_id` int(11) NOT NULL,
  `applied_amount` decimal(15,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_or_delivery`
--

INSERT INTO `tbl_or_delivery` (`id`, `or_id`, `delivery_id`, `applied_amount`) VALUES
(8, 51, 24, 400.00),
(11, 54, 26, 500.00),
(12, 54, 27, 400.00),
(13, 55, 26, 500.00),
(14, 52, 24, 100.00),
(15, 52, 25, 700.00),
(16, 48, 22, 500.00),
(17, 56, 27, 100.00),
(19, 59, 28, 100.00),
(21, 61, 33, 100.00);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_or_invoice`
--

CREATE TABLE `tbl_or_invoice` (
  `id` int(11) NOT NULL,
  `or_id` int(11) NOT NULL,
  `charge_invoice_id` int(11) NOT NULL,
  `applied_amount` decimal(15,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_or_invoice`
--

INSERT INTO `tbl_or_invoice` (`id`, `or_id`, `charge_invoice_id`, `applied_amount`) VALUES
(35, 44, 27, 400.00),
(37, 45, 23, 100.00),
(42, 50, 29, 400.00),
(43, 53, 29, 70.00),
(46, 58, 30, 1280.00);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment_history`
--

CREATE TABLE `tbl_payment_history` (
  `id` int(11) NOT NULL,
  `or_id` int(11) NOT NULL,
  `charge_invoice_id` int(11) NOT NULL,
  `amount_received` decimal(15,2) NOT NULL,
  `net_value` decimal(15,2) DEFAULT 0.00,
  `percent_one` decimal(15,2) DEFAULT 0.00,
  `percent_five` decimal(15,2) DEFAULT 0.00,
  `status` enum('Active','Cancelled') DEFAULT 'Active',
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `is_government_payment` tinyint(1) DEFAULT 0 COMMENT 'Flag for government payment processing',
  `payment_reference` varchar(100) DEFAULT NULL COMMENT 'Reference number for tracking'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_payment_history`
--

INSERT INTO `tbl_payment_history` (`id`, `or_id`, `charge_invoice_id`, `amount_received`, `net_value`, `percent_one`, `percent_five`, `status`, `created_by`, `created_at`, `is_government_payment`, `payment_reference`) VALUES
(1, 39, 23, 100.00, 100.00, 0.00, 0.00, 'Active', 1, '2025-12-10 21:41:44', 0, NULL),
(2, 40, 27, 250.00, 400.00, 0.00, 0.00, 'Active', 1, '2025-12-10 21:42:58', 0, NULL),
(3, 41, 27, 150.00, 400.00, 0.00, 0.00, 'Active', 1, '2025-12-10 21:50:49', 0, NULL),
(4, 41, 27, 150.00, 400.00, 0.00, 0.00, 'Active', NULL, '2025-12-10 21:51:05', 0, NULL),
(5, 41, 27, 150.00, 400.00, 0.00, 0.00, 'Active', NULL, '2025-12-10 21:51:09', 0, NULL),
(6, 41, 27, 250.00, 400.00, 0.00, 0.00, 'Active', NULL, '2025-12-10 21:51:27', 0, NULL),
(7, 42, 27, 350.00, 400.00, 0.00, 0.00, 'Active', 1, '2025-12-10 21:52:09', 0, NULL),
(8, 42, 27, 50.00, 400.00, 0.00, 0.00, 'Active', NULL, '2025-12-10 21:52:35', 0, NULL),
(9, 43, 27, 350.00, 400.00, 0.00, 0.00, 'Active', 1, '2025-12-10 21:53:15', 0, NULL),
(10, 44, 27, 350.00, 400.00, 0.00, 0.00, 'Active', 1, '2025-12-10 22:00:19', 0, NULL),
(11, 44, 27, 50.00, 400.00, 0.00, 0.00, 'Active', NULL, '2025-12-10 22:03:30', 0, NULL),
(12, 44, 27, 350.00, 400.00, 0.00, 0.00, 'Active', NULL, '2025-12-10 22:03:43', 0, NULL),
(13, 44, 27, 400.00, 400.00, 0.00, 0.00, 'Active', NULL, '2025-12-10 22:11:19', 0, NULL),
(14, 45, 23, 100.00, 150.00, 0.00, 0.00, 'Active', 1, '2025-12-10 22:21:35', 0, NULL),
(15, 45, 23, 100.00, 150.00, 0.00, 0.00, 'Active', NULL, '2025-12-10 22:21:46', 0, NULL),
(16, 46, 25, 250.00, 282.00, 3.00, 15.00, 'Active', 1, '2025-12-10 22:22:06', 1, NULL),
(17, 46, 25, 250.00, 282.00, 3.00, 15.00, 'Active', NULL, '2025-12-10 22:22:54', 1, NULL),
(18, 49, 29, 400.00, 470.00, 5.00, 25.00, 'Active', 1, '2025-12-13 10:50:20', 1, NULL),
(19, 49, 29, 470.00, 470.00, 5.00, 25.00, 'Active', NULL, '2025-12-13 10:53:12', 1, NULL),
(20, 50, 29, 400.00, 470.00, 5.00, 25.00, 'Active', 1, '2025-12-13 11:06:25', 1, NULL),
(21, 53, 29, 70.00, 470.00, 5.00, 25.00, 'Active', NULL, '2025-12-13 11:22:02', 1, NULL),
(22, 57, 30, 600.00, 1880.00, 20.00, 100.00, 'Active', NULL, '2025-12-13 13:21:46', 1, NULL),
(23, 57, 31, 500.00, 4700.00, 50.00, 250.00, 'Active', NULL, '2025-12-13 13:21:46', 1, NULL),
(24, 58, 30, 1280.00, 1880.00, 20.00, 100.00, 'Active', 1, '2025-12-13 13:23:03', 1, NULL),
(25, 60, 31, 400.00, 4700.00, 50.00, 250.00, 'Active', 1, '2025-12-13 15:36:04', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('Admin','Encoder','Viewer','Faculty','Staff','Dean','Director') DEFAULT 'Encoder',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `first_name`, `middle_name`, `last_name`, `position`, `username`, `password_hash`, `role`, `created_at`) VALUES
(1, 'Admin', '', 'System', 'Administrator', 'super', '$2y$10$VvC9sWd7qymmX5gPrU1NBu4AY/kcsmFmUd3fxEGwlbvVWGJxW.pzq', 'Admin', '2025-12-07 17:44:26'),
(3, 'encoder', '', '1', 'encoder', 'encoder', '$2y$10$gIsqnNOG6ykQWX3xGERfiewchH/mzTPI/2qV55qYP/He5MN6x8iNm', 'Encoder', '2025-12-07 20:34:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_logs`
--

CREATE TABLE `tbl_user_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `login_time` datetime DEFAULT NULL,
  `logout_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_activity_logs`
--
ALTER TABLE `tbl_activity_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_app_setting`
--
ALTER TABLE `tbl_app_setting`
  ADD PRIMARY KEY (`setting_id`);

--
-- Indexes for table `tbl_banks`
--
ALTER TABLE `tbl_banks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_charge_invoices`
--
ALTER TABLE `tbl_charge_invoices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoice_no` (`invoice_no`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `tbl_charge_invoices_ibfk_2` (`created_by`),
  ADD KEY `idx_charge_invoices_is_government` (`is_government`);

--
-- Indexes for table `tbl_customers`
--
ALTER TABLE `tbl_customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_deliveries`
--
ALTER TABLE `tbl_deliveries`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `delivery_no` (`delivery_no`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `tbl_invoice_deliveries`
--
ALTER TABLE `tbl_invoice_deliveries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `charge_invoice_id` (`charge_invoice_id`),
  ADD KEY `delivery_id` (`delivery_id`);

--
-- Indexes for table `tbl_official_receipts`
--
ALTER TABLE `tbl_official_receipts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `or_no` (`or_no`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `bank_id` (`bank_id`),
  ADD KEY `tbl_official_receipts_ibfk_3` (`created_by`);

--
-- Indexes for table `tbl_or_delivery`
--
ALTER TABLE `tbl_or_delivery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `or_id` (`or_id`),
  ADD KEY `delivery_id` (`delivery_id`);

--
-- Indexes for table `tbl_or_invoice`
--
ALTER TABLE `tbl_or_invoice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `or_id` (`or_id`),
  ADD KEY `charge_invoice_id` (`charge_invoice_id`);

--
-- Indexes for table `tbl_payment_history`
--
ALTER TABLE `tbl_payment_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `or_id` (`or_id`),
  ADD KEY `charge_invoice_id` (`charge_invoice_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_payment_history_is_government` (`is_government_payment`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `tbl_user_logs`
--
ALTER TABLE `tbl_user_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_activity_logs`
--
ALTER TABLE `tbl_activity_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=354;

--
-- AUTO_INCREMENT for table `tbl_app_setting`
--
ALTER TABLE `tbl_app_setting`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_banks`
--
ALTER TABLE `tbl_banks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_charge_invoices`
--
ALTER TABLE `tbl_charge_invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `tbl_customers`
--
ALTER TABLE `tbl_customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_deliveries`
--
ALTER TABLE `tbl_deliveries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `tbl_invoice_deliveries`
--
ALTER TABLE `tbl_invoice_deliveries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_official_receipts`
--
ALTER TABLE `tbl_official_receipts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `tbl_or_delivery`
--
ALTER TABLE `tbl_or_delivery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbl_or_invoice`
--
ALTER TABLE `tbl_or_invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `tbl_payment_history`
--
ALTER TABLE `tbl_payment_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_user_logs`
--
ALTER TABLE `tbl_user_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_activity_logs`
--
ALTER TABLE `tbl_activity_logs`
  ADD CONSTRAINT `tbl_activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_or_delivery`
--
ALTER TABLE `tbl_or_delivery`
  ADD CONSTRAINT `tbl_or_delivery_ibfk_1` FOREIGN KEY (`or_id`) REFERENCES `tbl_official_receipts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tbl_or_delivery_ibfk_2` FOREIGN KEY (`delivery_id`) REFERENCES `tbl_deliveries` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
